ADWIO V4 verified update
- versionCode 4 / versionName 2.2.0
- startup crash protection
- Live categories beside channels
- Movies/Series 6-8 poster grid
- Series season + episode selection
- background playback behavior
The V4 workflow verifies critical files before committing.
