ADWIO V5 Crash-Hardened Diagnostic Update
- versionCode 5 / versionName 2.3.0
- global uncaught exception screen
- safer fullscreen initialization
- retains V4 categories, poster grid, season selection and background playback
If a crash remains, the app will show the exact stack trace instead of only the Android keeps-stopping dialog.
