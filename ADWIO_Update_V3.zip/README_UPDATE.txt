ADWIO Update V3
================
This package contains only the files that must be replaced/added in the GitHub project.

Main changes:
- Fixes startup crash around null ANDROID_ID and adds visible startup error handling.
- Live TV: categories panel beside channel list.
- Movies: 6 posters per row on smaller landscape screens, 8 on large TV screens.
- Series: same poster grid as movies.
- Series season picker before episode picker.
- Background playback continues when app is minimized; Back from player stops playback.
- versionCode raised to 3 / versionName 2.1.0.
- Debug builds no longer require release keystore.

Copy the entire "app" folder from this update over the project's existing "app" folder,
preserving all other files in the repository.
